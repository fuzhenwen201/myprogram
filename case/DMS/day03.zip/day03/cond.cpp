//生产者和消费者模型
#include <cstdio>
#include <pthread.h>
#include <unistd.h>

//定义一个仓库
char buf[5];
//定义一个变量表示数组的下标
int pos;
//1.定义一个互斥量
pthread_mutex_t mutex;
//11.定义两个条件变量
pthread_cond_t full; 
pthread_cond_t empty;

//打印仓库中的所有数据
void print(void)
{
	if(pos > 0)
	{
		printf("仓库中的数据有：");
		for(int i = 0; i < pos; i++)
		{
			printf("%c ",buf[i]);
		}
		printf("\n");
	}
}

//生产者线程处理函数
void* producer(void* p)
{
	for(char c = 'A'; c <= 'Z'; c++)
	{
		//3.生产的时候加锁
		pthread_mutex_lock(&mutex);
		if(5 == pos)
		{
			//break;
			//13.阻塞线程，并且释放互斥锁
			pthread_cond_wait(&full,&mutex);
		}
		printf("Push:%c\n",c);
		buf[pos++] = c;
		print();
		//14.一旦生产之后，释放消费者线程
		pthread_cond_signal(&empty);

		//4.生产结束的时候解锁
		pthread_mutex_unlock(&mutex);
	}
}

//消费者线程处理函数
void* customer(void* p)
{
	for(int i = 0; i < 26; i++)
	{
		usleep(20000);
		//3.消费的时候加锁
		pthread_mutex_lock(&mutex);
		if(0 == pos)
		{
			//break;
			//13.阻塞线程，释放互斥锁
			pthread_cond_wait(&empty,&mutex);
		}
		printf("Pop:%c\n",buf[--pos]);
		print();
		//14.一旦消费，即刻通知生产
		pthread_cond_signal(&full);
		
		//4.消费结束的时候解锁
		pthread_mutex_unlock(&mutex);
	}
}

int main(void)
{
	//2.初始化互斥量
	pthread_mutex_init(&mutex,0);
	//12.初始化条件变量
	pthread_cond_init(&full,0);
	pthread_cond_init(&empty,0);

	//分别创建生产者和消费者线程
	pthread_t tid1,tid2;
	pthread_create(&tid1,0,producer,0);
	pthread_create(&tid2,0,customer,0);
	//等待线程结束
	pthread_join(tid1,0);
	pthread_join(tid2,0);

	//5.删除互斥量
	pthread_mutex_destroy(&mutex);
	//15.删除条件变量
	pthread_cond_destroy(&full);
	pthread_cond_destroy(&empty);
	return 0;
}

